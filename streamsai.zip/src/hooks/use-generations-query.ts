import { useQuery, useQueryClient } from "@tanstack/react-query";
import { listGenerations, type GenerationRecord } from "@/lib/generations";

interface UseGenerationsQueryOptions {
    type?: "video" | "image" | "script" | "voice";
    limit?: number;
}

/**
 * Cached wrapper around listGenerations using React Query.
 * Cache key: ['generations', type] – each type has its own cache bucket.
 * staleTime: 2 minutes – navigating back to a page shows data instantly.
 */
export function useGenerationsQuery({ type, limit = 12 }: UseGenerationsQueryOptions = {}) {
    const queryKey = ["generations", type ?? "all"];

    const { data = [], isLoading, error } = useQuery<GenerationRecord[]>({
        queryKey,
        queryFn: () => listGenerations({ type, limit }),
        staleTime: 2 * 60 * 1000, // 2 minutes
        gcTime: 5 * 60 * 1000,    // keep in memory 5 minutes after last use
    });

    return {
        historyItems: data,
        historyLoading: isLoading,
        historyError: error instanceof Error ? error.message : "",
        queryKey,
    };
}

/**
 * Returns a helper to optimistically prepend a new generation into the
 * React Query cache for a given type, so the UI updates immediately.
 */
export function usePrependGeneration() {
    const queryClient = useQueryClient();

    return function prependGeneration(item: GenerationRecord) {
        const type = item.type;
        const queryKey = ["generations", type];
        const allKey = ["generations", "all"];

        // Prepend into the type-specific cache
        queryClient.setQueryData<GenerationRecord[]>(queryKey, (old = []) => [item, ...old]);
        // Also prepend into the "all" cache (used by video page which shows all types)
        queryClient.setQueryData<GenerationRecord[]>(allKey, (old = []) => [item, ...old]);
        // Invalidate library cache so it stays fresh too
        queryClient.invalidateQueries({ queryKey: ["generations"] });
    };
}
