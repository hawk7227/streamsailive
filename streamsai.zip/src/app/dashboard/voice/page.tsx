"use client";

import { useState } from "react";
import Link from "next/link";
import { useAuth } from "@/contexts/AuthContext";
import {
  createGeneration,
  type GenerationRecord,
} from "@/lib/generations";
import { formatRelativeTime, truncateText } from "@/lib/formatters";
import AIAssistant from "@/components/dashboard/AIAssistant";
import { useGenerationsQuery, usePrependGeneration } from "@/hooks/use-generations-query";

import QuickTemplates, { Template } from "@/components/dashboard/QuickTemplates";

const TEMPLATE_STORAGE_KEY = "streamsai.voice.templates";

type VoiceTemplate = Template & {
  prompt: string;
  style: string;
  speed: string;
};

const DEFAULT_TEMPLATES: VoiceTemplate[] = [
  {
    id: "storytelling",
    name: "Storytelling",
    icon: "📖",
    uses: "4.5k",
    prompt: "Once upon a time, in a land far far away...",
    style: "Narrator",
    speed: "Slow",
    isDefault: true,
  },
  {
    id: "ad-read",
    name: "Ad Read",
    icon: "📢",
    uses: "3.2k",
    prompt: "This episode is brought to you by...",
    style: "Professional",
    speed: "Normal",
    isDefault: true,
  },
  {
    id: "casual-chat",
    name: "Casual Chat",
    icon: "🗣️",
    uses: "2.8k",
    prompt: "Hey guys, just wanted to give you a quick update...",
    style: "Casual",
    speed: "Normal",
    isDefault: true,
  },
  {
    id: "disclaimer",
    name: "Disclaimer",
    icon: "⚡",
    uses: "1.2k",
    prompt: "Terms and conditions apply. See website for details.",
    style: "Professional",
    speed: "Fast",
    isDefault: true,
  },
];

export default function VoicePage() {
  const { usage, usageLoading, incrementUsage } = useAuth();
  const [text, setText] = useState("");
  const [voice, setVoice] = useState("Natural");
  const [speed, setSpeed] = useState("Normal");
  const [isGenerating, setIsGenerating] = useState(false);
  const [usageError, setUsageError] = useState("");
  const [previewItem, setPreviewItem] = useState<GenerationRecord | null>(null);
  const [activePreview, setActivePreview] = useState<GenerationRecord | null>(null);

  // React Query cache – instant data on back-navigation
  const { historyItems, historyLoading, historyError } = useGenerationsQuery({ type: "voice", limit: 8 });
  const prependGeneration = usePrependGeneration();

  const isLimitReached =
    typeof usage?.limit === "number" && usage.used >= usage.limit;

  const handleGenerate = async () => {
    if (isLimitReached || usageLoading || isGenerating) {
      return;
    }

    if (!text.trim()) {
      setUsageError("Please enter text for the voiceover.");
      return;
    }

    setUsageError("");
    setIsGenerating(true);

    const { error } = await incrementUsage(1);
    if (error) {
      setUsageError(error);
      setIsGenerating(false);
      return;
    }

    try {
      const created = await createGeneration({
        type: "voice",
        prompt: text,
        title: truncateText(text, 48),
        style: voice,
        quality: speed,
      });
      // Optimistically inject into cache so the panel updates instantly
      prependGeneration(created);
      setActivePreview(created);
    } catch (createError) {
      setUsageError(
        createError instanceof Error
          ? createError.message
          : "Unable to save generation"
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleTemplateApply = (template: Template) => {
    const t = template as VoiceTemplate;
    setText(t.prompt);
    setVoice(t.style);
    setSpeed(t.speed);
  };

  const tabs = [
    { id: "script", label: "Script", icon: "📝" },
    { id: "voice", label: "Voice", icon: "🎙️" },
    { id: "image", label: "Image", icon: "🖼️" },
    { id: "video", label: "Video", icon: "🎬" },
  ];

  return (
    <>
    <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8">
      <div className="space-y-6">
        {/* Product Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {tabs.map((tab) => (
            <Link
              key={tab.id}
              href={`/dashboard/${tab.id}`}
              className={`flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium whitespace-nowrap transition-all ${
                tab.id === "voice"
                  ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                  : "border-border-color bg-bg-secondary text-text-secondary hover:border-accent-indigo/50"
              }`}
            >
              <span className="text-xl">{tab.icon}</span> {tab.label}
            </Link>
          ))}
        </div>



        {/* Templates Bar */}
        <QuickTemplates
          storageKey={TEMPLATE_STORAGE_KEY}
          defaultTemplates={DEFAULT_TEMPLATES}
          onApply={handleTemplateApply}
        />

        {/* Main Generation Panel */}
        <div className="bg-bg-secondary border border-border-color rounded-2xl overflow-hidden">
          <div className="px-6 py-5 border-b border-border-color flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent-purple to-accent-pink flex items-center justify-center">
                🎙️
              </div>
              <span className="font-semibold">Voice Generation</span>
            </div>
          </div>

          <div className="p-6 space-y-6">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <span>✨</span> Enter text to convert to speech
                </div>
                <span className="text-xs text-text-muted">
                  {text.length} / 5000
                </span>
              </div>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="w-full h-48 px-4 py-4 rounded-xl border border-border-color bg-bg-tertiary text-white text-[15px] leading-relaxed resize-none focus:outline-none focus:border-accent-indigo placeholder-text-muted"
                placeholder="Type or paste the text you want to convert to speech..."
                maxLength={5000}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-bg-tertiary rounded-xl p-4">
                <p className="text-[10px] uppercase tracking-wider text-text-muted mb-3">
                  Voice Style
                </p>
                <select
                  value={voice}
                  onChange={(e) => setVoice(e.target.value)}
                  className="w-full py-2.5 px-3 rounded-lg border border-border-color bg-bg-secondary text-white text-sm appearance-none cursor-pointer focus:outline-none focus:border-accent-indigo"
                >
                  <option>Natural</option>
                  <option>Professional</option>
                  <option>Casual</option>
                  <option>Narrator</option>
                </select>
              </div>
              <div className="bg-bg-tertiary rounded-xl p-4">
                <p className="text-[10px] uppercase tracking-wider text-text-muted mb-3">
                  Speed
                </p>
                <select
                  value={speed}
                  onChange={(e) => setSpeed(e.target.value)}
                  className="w-full py-2.5 px-3 rounded-lg border border-border-color bg-bg-secondary text-white text-sm appearance-none cursor-pointer focus:outline-none focus:border-accent-indigo"
                >
                  <option>Slow</option>
                  <option>Normal</option>
                  <option>Fast</option>
                </select>
              </div>
            </div>

            <button
              type="button"
              onClick={handleGenerate}
              disabled={isLimitReached || usageLoading || isGenerating}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-accent-purple to-accent-pink text-white font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-accent-purple/30 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {isLimitReached
                ? "Limit Reached"
                : isGenerating
                ? "Generating..."
                : "✨ Generate Voice"}
            </button>
            {usageError && (
              <p className="text-xs text-accent-red">{usageError}</p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Inline Preview / Shimmer */}
        {(isGenerating || activePreview) && (
          <div className="bg-bg-secondary border border-border-color rounded-2xl overflow-hidden p-6 shadow-xl relative mt-0">
            <h3 className="text-sm font-medium mb-4 flex items-center gap-2">
              <span className="text-accent-purple">👁️</span> Preview
            </h3>
            {isGenerating ? (
              <div className="w-full h-24 rounded-xl bg-bg-tertiary animate-pulse border border-border-color flex flex-col items-center justify-center gap-2 text-text-muted">
                <div className="text-2xl animate-bounce">🎙️</div>
                <p className="text-sm font-medium animate-pulse text-accent-purple">Synthesizing voice...</p>
              </div>
            ) : activePreview ? (
              <div className="relative group rounded-xl overflow-hidden border border-border-color p-4 bg-bg-tertiary">
                {activePreview.output_url ? (
                  <audio
                    src={activePreview.output_url}
                    controls
                    autoPlay
                    className="w-full"
                  />
                ) : (
                  <div className="w-full py-4 flex flex-col items-center justify-center gap-2 text-xs text-accent-red">
                    <span>❌</span>
                    <span>Generation failed</span>
                  </div>
                )}
                <div className="mt-3 flex gap-2">
                  {activePreview.style && (
                    <span className="text-xs px-2 py-1 bg-white/5 rounded-md text-text-muted">{activePreview.style}</span>
                  )}
                  {activePreview.quality && (
                    <span className="text-xs px-2 py-1 bg-white/5 rounded-md text-text-muted">{activePreview.quality}</span>
                  )}
                </div>
              </div>
            ) : null}
          </div>
        )}

        {/* AI Assistant */}
        <AIAssistant
          context={{
            type: "voice",
            prompt: text,
            settings: { voice, speed },
          }}
          onApplyPrompt={(newText) => setText(newText)}
          onUpdateSettings={(key, value) => {
            if (key === "voice") setVoice(value);
            if (key === "speed") setSpeed(value);
          }}
        />

        <div className="bg-bg-secondary border border-border-color rounded-2xl p-4">
          <h3 className="text-sm font-medium mb-3">Recent Voices</h3>
          {historyLoading && (
            <p className="text-xs text-text-muted">Loading voices...</p>
          )}
          {!historyLoading && historyError && (
            <p className="text-xs text-accent-red">{historyError}</p>
          )}
          {!historyLoading && !historyError && historyItems.length === 0 && (
            <p className="text-xs text-text-muted">No voices generated yet</p>
          )}
          {!historyLoading &&
            !historyError &&
            historyItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-3 py-2 border-b border-white/[0.05] last:border-0 cursor-pointer hover:bg-white/5 rounded-lg px-2 -mx-2"
                onClick={() => setPreviewItem(item)}
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-accent-purple/20 to-accent-pink/20 flex items-center justify-center">
                  🎙️
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">
                    {truncateText(item.title ?? item.prompt, 40)}
                  </p>
                  <p className="text-[10px] text-text-muted">
                    {item.style && `${item.style} • `}
                    {item.quality && `${item.quality} • `}
                    {formatRelativeTime(item.created_at)}
                  </p>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
      {previewItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4 py-6"
          onClick={() => setPreviewItem(null)}
        >
          <div
            className="w-full max-w-3xl bg-bg-secondary border border-border-color rounded-2xl shadow-xl overflow-hidden"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-border-color flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold">
                  {truncateText(previewItem.title ?? previewItem.prompt, 80)}
                </h3>
                <p className="text-[11px] text-text-muted">
                  VOICE • {formatRelativeTime(previewItem.created_at)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="text-text-muted hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="p-6 space-y-4">
              {previewItem.output_url ? (
                <audio
                  className="w-full"
                  controls
                  src={previewItem.output_url}
                />
              ) : (
                <div className="w-full rounded-xl border border-dashed border-border-color flex items-center justify-center text-xs text-text-muted px-4 py-10">
                  No audio URL set yet.
                </div>
              )}
              <p className="text-xs text-text-muted">
                {previewItem.style && `${previewItem.style} • `}
                {previewItem.quality && `${previewItem.quality} • `}
                {formatRelativeTime(previewItem.created_at)}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
