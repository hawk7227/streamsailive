"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useAuth } from "@/contexts/AuthContext";
import {
  createGeneration,
  listGenerations,
  type GenerationRecord,
} from "@/lib/generations";
import { formatRelativeTime, truncateText } from "@/lib/formatters";
import AIAssistant from "@/components/dashboard/AIAssistant";
import { useGenerationsQuery, usePrependGeneration } from "@/hooks/use-generations-query";
import { useQueryClient } from "@tanstack/react-query";

import QuickTemplates, { Template } from "@/components/dashboard/QuickTemplates";

const TEMPLATE_STORAGE_KEY = "streamsai.video.templates";

type VideoTemplate = Template & {
  prompt: string;
  aspectRatio: string;
  duration: string;
  quality: string;
};



const DEFAULT_TEMPLATES: VideoTemplate[] = [
  {
    id: "product-demo",
    name: "Product Demo",
    icon: "🎥",
    uses: "2.4k",
    prompt:
      "A sleek product demo showcasing a smartphone rotating in soft studio light, clean background, crisp reflections",
    aspectRatio: "16:9",
    duration: "8s",
    quality: "1080p Full HD",
    isDefault: true,
  },
  {
    id: "social-reel",
    name: "Social Reel",
    icon: "📱",
    uses: "1.8k",
    prompt:
      "Fast-paced montage of lifestyle shots with dynamic cuts, vibrant colors, and energetic transitions",
    aspectRatio: "9:16",
    duration: "8s",
    quality: "1080p Full HD",
    isDefault: true,
  },
  {
    id: "corporate-intro",
    name: "Corporate Intro",
    icon: "🏢",
    uses: "1.2k",
    prompt:
      "Corporate intro with aerial city skyline, modern office interiors, and subtle motion graphics",
    aspectRatio: "16:9",
    duration: "16s",
    quality: "4K Ultra HD",
    isDefault: true,
  },
  {
    id: "tutorial",
    name: "Tutorial",
    icon: "🎓",
    uses: "980",
    prompt:
      "Screen-record style tutorial with clear callouts, smooth zooms, and minimal background",
    aspectRatio: "16:9",
    duration: "16s",
    quality: "1080p Full HD",
    isDefault: true,
  },
  {
    id: "ecommerce",
    name: "E-commerce",
    icon: "🛍️",
    uses: "756",
    prompt:
      "Lifestyle product showcase with soft natural light, shallow depth of field, and clean typography",
    aspectRatio: "1:1",
    duration: "8s",
    quality: "1080p Full HD",
    isDefault: true,
  },
];

export default function VideoPage() {
  const { usage, usageLoading, incrementUsage } = useAuth();
  const [prompt, setPrompt] = useState(
    "A breathtaking aerial view of a futuristic city at sunset, with flying cars weaving between towering glass skyscrapers, neon lights beginning to glow"
  );
  const [aspectRatio, setAspectRatio] = useState("16:9");
  const [duration, setDuration] = useState("8s");
  const [quality, setQuality] = useState("1080p Full HD");
  const [activeTab, setActiveTab] = useState("All");
  const [isGenerating, setIsGenerating] = useState(false);
  const [usageError, setUsageError] = useState("");

  // React Query cache – instant data on back-navigation
  const { historyItems, historyLoading, historyError } = useGenerationsQuery({ limit: 12 });
  const prependGeneration = usePrependGeneration();
  const queryClient = useQueryClient();

  const [previewItem, setPreviewItem] = useState<GenerationRecord | null>(null);
  const [activePreview, setActivePreview] = useState<GenerationRecord | null>(null);

  const isLimitReached =
    typeof usage?.limit === "number" && usage.used >= usage.limit;

  const handleGenerate = async () => {
    if (isLimitReached || usageLoading || isGenerating) {
      return;
    }

    setUsageError("");
    setIsGenerating(true);

    const { error } = await incrementUsage(1);
    if (error) {
      setUsageError(error);
      setIsGenerating(false);
      return;
    }

    try {
      const created = await createGeneration({
        type: "video",
        prompt,
        title: truncateText(prompt, 48),
        status: "pending",
        aspectRatio,
        duration,
        quality,
      });
      // Optimistically inject into cache so history panel updates instantly
      prependGeneration(created);
      setActivePreview(created);
      if (created.status !== "pending") {
        setIsGenerating(false);
      }
    } catch (createError) {
      setUsageError(
        createError instanceof Error
          ? createError.message
          : "Unable to save generation"
      );
      setIsGenerating(false);
    }
  };

  const tabs = [
    { id: "script", label: "Script", icon: "📝" },
    { id: "voice", label: "Voice", icon: "🎙️" },
    { id: "image", label: "Image", icon: "🖼️" },
    { id: "video", label: "Video", icon: "🎬" },
  ];



  // NOTE: history data is now served from React Query cache above.
  // No manual useEffect fetch needed.

  // Polling logic for pending videos
  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    const checkStatus = async () => {
      if (activePreview && activePreview.status === "pending") {
        try {
          // Trigger the cron job to poll OpenAI before fetching the list
          await fetch('/api/cron/check-videos').catch(console.error);

          const recentGenerations = await listGenerations({ limit: 12 });
          const updatedItem = recentGenerations.find(g => g.id === activePreview.id);
          
          if (updatedItem && updatedItem.status !== "pending") {
            setActivePreview(updatedItem);
            
            // Update in the React Query cache
            queryClient.setQueryData<GenerationRecord[]>(["generations", "all"], (old = []) =>
              old.map((item) => item.id === updatedItem.id ? updatedItem : item)
            );
            
            if (updatedItem.status === "completed" || updatedItem.status === "failed") {
              setIsGenerating(false); // Ensure generating state is off
            }
          } else if (updatedItem && updatedItem.status === "pending") {
            // Update preview and history items if progress changed
            if (updatedItem.progress !== activePreview.progress) {
              setActivePreview(updatedItem);
              queryClient.setQueryData<GenerationRecord[]>(["generations", "all"], (old = []) =>
                old.map((item) => item.id === updatedItem.id ? updatedItem : item)
              );
            }
          }
        } catch(e) {
          console.error("Polling error:", e);
        }
      }
      
      if (activePreview?.status === "pending") {
         timeout = setTimeout(checkStatus, 5000);
      }
    };

    if (activePreview?.status === "pending") {
      timeout = setTimeout(checkStatus, 5000); // 5 sec interval
    }

    return () => clearTimeout(timeout);
  }, [activePreview]);

  const filteredHistory = useMemo(() => {
    if (activeTab === "All") {
      return historyItems;
    }
    const normalized = activeTab.toLowerCase();
    return historyItems.filter((item) => item.type === normalized);
  }, [activeTab, historyItems]);

  const handleTemplateApply = (template: Template) => {
    const t = template as VideoTemplate;
    setPrompt(t.prompt);
    setAspectRatio(t.aspectRatio);
    setDuration(t.duration);
    setQuality(t.quality);
  };





  return (
    <>
      <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8">
        {/* Left Column */}
        <div className="space-y-6">
        {/* Product Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {tabs.map((tab) => (
            <Link
              key={tab.id}
              href={`/dashboard/${tab.id}`}
              className={`flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium whitespace-nowrap transition-all ${
                tab.id === "video"
                  ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                  : "border-border-color bg-bg-secondary text-text-secondary hover:border-accent-indigo/50"
              }`}
            >
              <span className="text-xl">{tab.icon}</span> {tab.label}
            </Link>
          ))}
        </div>

        {/* Templates Bar */}
        <QuickTemplates
          storageKey={TEMPLATE_STORAGE_KEY}
          defaultTemplates={DEFAULT_TEMPLATES}
          onApply={handleTemplateApply}
        />

        {/* Main Generation Panel */}
        <div className="bg-bg-secondary border border-border-color rounded-2xl overflow-hidden">
          <div className="px-6 py-5 border-b border-border-color flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-linear-to-br from-accent-indigo to-accent-purple flex items-center justify-center">
                🎬
              </div>
              <span className="font-semibold">Video Generation</span>
            </div>
            <div className="flex gap-2">
              <button className="px-3 py-1.5 rounded-lg border border-border-color text-text-secondary text-xs hover:bg-bg-tertiary transition-colors">
                🕐 History
              </button>
              <button
                type="button"
                className="px-3 py-1.5 rounded-lg border border-border-color text-text-secondary text-xs hover:bg-bg-tertiary transition-colors"
              >
                ⭐ Templates
              </button>
            </div>
          </div>

          <div className="p-6 space-y-6">
            {/* Prompt */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <span>✨</span> Describe your video
                </div>
                <span className="text-xs text-text-muted">
                  {prompt.length} / 500
                </span>
              </div>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full h-36 px-4 py-4 rounded-xl border border-border-color bg-bg-tertiary text-white text-[15px] leading-relaxed resize-none focus:outline-none focus:border-accent-indigo placeholder-text-muted"
                placeholder="Describe your video..."
                maxLength={500}
              />

              {/* Prompt Score */}
              <div className="flex items-center gap-4 mt-3 p-4 bg-bg-tertiary rounded-xl">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center relative"
                  style={{
                    background:
                      "conic-gradient(#10b981 0deg, #10b981 270deg, #1a1a24 270deg)",
                  }}
                >
                  <div className="absolute inset-1 bg-bg-tertiary rounded-full"></div>
                  <span className="relative text-sm font-bold text-accent-emerald">
                    75
                  </span>
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium mb-1">Good prompt quality</p>
                  <div className="flex flex-wrap gap-2">
                    <span className="flex items-center gap-1 text-xs text-accent-emerald">
                      ✓ Detailed
                    </span>
                    <span className="flex items-center gap-1 text-xs text-accent-emerald">
                      ✓ Visual
                    </span>
                    <span className="flex items-center gap-1 text-xs text-text-muted">
                      ○ Add style
                    </span>
                    <span className="flex items-center gap-1 text-xs text-text-muted">
                      ○ Camera angle
                    </span>
                  </div>
                </div>

              </div>
            </div>

            {/* Settings */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-bg-tertiary rounded-xl p-4">
                <p className="text-[10px] uppercase tracking-wider text-text-muted mb-3">
                  Aspect Ratio
                </p>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setAspectRatio("16:9")}
                    className={`flex-1 py-2.5 rounded-lg border text-xs font-medium flex flex-col items-center transition-colors ${
                      aspectRatio === "16:9"
                        ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                        : "border-border-color bg-bg-secondary text-text-secondary"
                    }`}
                  >
                    <span className="text-lg mb-0.5">🖥️</span> 16:9
                  </button>
                  <button
                    onClick={() => setAspectRatio("9:16")}
                    className={`flex-1 py-2.5 rounded-lg border text-xs font-medium flex flex-col items-center transition-colors ${
                      aspectRatio === "9:16"
                        ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                        : "border-border-color bg-bg-secondary text-text-secondary"
                    }`}
                  >
                    <span className="text-lg mb-0.5">📱</span> 9:16
                  </button>
                  <button
                    onClick={() => setAspectRatio("1:1")}
                    className={`flex-1 py-2.5 rounded-lg border text-xs font-medium flex flex-col items-center transition-colors ${
                      aspectRatio === "1:1"
                        ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                        : "border-border-color bg-bg-secondary text-text-secondary"
                    }`}
                  >
                    <span className="text-lg mb-0.5">⬜</span> 1:1
                  </button>
                </div>
              </div>
              <div className="bg-bg-tertiary rounded-xl p-4">
                <p className="text-[10px] uppercase tracking-wider text-text-muted mb-3">
                  Duration
                </p>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setDuration("4s")}
                    className={`flex-1 py-2.5 rounded-lg border text-xs font-medium transition-colors ${
                      duration === "4s"
                        ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                        : "border-border-color bg-bg-secondary text-text-secondary"
                    }`}
                  >
                    4s
                  </button>
                  <button
                    onClick={() => setDuration("8s")}
                    className={`flex-1 py-2.5 rounded-lg border text-xs font-medium transition-colors ${
                      duration === "8s"
                        ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                        : "border-border-color bg-bg-secondary text-text-secondary"
                    }`}
                  >
                    8s
                  </button>
                  <button
                    onClick={() => setDuration("16s")}
                    className={`flex-1 py-2.5 rounded-lg border text-xs font-medium transition-colors ${
                      duration === "16s"
                        ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                        : "border-border-color bg-bg-secondary text-text-secondary"
                    }`}
                  >
                    16s
                  </button>
                </div>
              </div>
              <div className="bg-bg-tertiary rounded-xl p-4">
                <p className="text-[10px] uppercase tracking-wider text-text-muted mb-3">
                  Quality
                </p>
                <select
                  value={quality}
                  onChange={(e) => setQuality(e.target.value)}
                  className="w-full py-2.5 px-3 rounded-lg border border-border-color bg-bg-secondary text-white text-sm appearance-none cursor-pointer focus:outline-none focus:border-accent-indigo"
                >
                  <option>1080p Full HD</option>
                  <option>720p HD</option>
                  <option>4K Ultra HD</option>
                </select>
              </div>
            </div>

            {/* Generate */}
            <button
              type="button"
              onClick={handleGenerate}
              disabled={isLimitReached || usageLoading || isGenerating}
              className="w-full py-4 rounded-xl bg-linear-to-r from-accent-indigo to-accent-purple text-white font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-accent-indigo/30 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {isLimitReached
                ? "Limit Reached"
                : isGenerating
                ? "Generating..."
                : "✨ Generate Video"}
            </button>
            {usageError && (
              <p className="text-xs text-accent-red">{usageError}</p>
            )}
          </div>
        </div>
      </div>

      {/* Right Column - AI Assistant & History */}
      <div className="space-y-6">
        {/* Inline Preview / Shimmer */}
        {(isGenerating || activePreview) && (
          <div className="bg-bg-secondary border border-border-color rounded-2xl overflow-hidden p-6 shadow-xl relative mt-0">
            <h3 className="text-sm font-medium mb-4 flex items-center gap-2">
              <span className="text-accent-indigo">👁️</span> Preview
            </h3>
            {isGenerating || activePreview?.status === "pending" ? (
              <div className="w-full aspect-video rounded-xl bg-bg-tertiary animate-pulse border border-border-color flex flex-col items-center justify-center gap-4 text-text-muted p-6 text-center">
                <div className="w-12 h-12 rounded-full border-[3px] border-t-accent-indigo border-r-transparent border-b-accent-purple border-l-transparent animate-spin mb-2"></div>
                <p className="text-sm font-medium animate-pulse text-accent-indigo">Generating video masterpiece... {activePreview?.progress ? `(${activePreview.progress}%)` : ""}</p>
                <p className="text-xs text-text-muted max-w-sm mt-2">
                  Video generation is processing in the cloud. This usually takes a few minutes. You can wait here!
                </p>
              </div>
            ) : activePreview?.output_url ? (
              <div className="relative group rounded-xl overflow-hidden border border-border-color">
                <video
                  src={activePreview.output_url}
                  controls
                  autoPlay
                  className="w-full aspect-video object-cover bg-black"
                />
                {/* Overlay with details */}
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/80 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none flex justify-between z-10">
                  <span className="text-xs font-medium text-white drop-shadow-md">
                    {activePreview.duration && `${activePreview.duration} • `}
                    {activePreview.aspect_ratio}
                  </span>
                  <span className="text-xs font-medium text-white drop-shadow-md">{activePreview.quality}</span>
                </div>
              </div>
            ) : activePreview?.status === "failed" ? (
               <div className="w-full aspect-video flex flex-col items-center justify-center gap-2 rounded-xl border border-border-color bg-bg-tertiary text-xs text-accent-red">
                  <span>❌</span>
                  <span>Generation failed</span>
               </div>
            ) : null}
          </div>
        )}

        {/* AI Assistant */}
        <AIAssistant
          context={{
            type: "video",
            prompt,
            settings: { aspectRatio, duration, quality },
          }}
          onApplyPrompt={(newPrompt) => setPrompt(newPrompt)}
          onUpdateSettings={(key, value) => {
            if (key === "aspectRatio") setAspectRatio(value);
            if (key === "duration") setDuration(value);
            if (key === "quality") setQuality(value);
          }}
        />

        {/* Recent History */}
        <div className="bg-bg-secondary border border-border-color rounded-2xl overflow-hidden">
          <div className="px-5 py-4 border-b border-border-color flex items-center justify-between">
            <span className="font-medium text-sm">Recent History</span>
            <div className="flex gap-1">
              <button
                onClick={() => setActiveTab("All")}
                className={`px-2 py-1 rounded text-xs transition-colors ${
                  activeTab === "All"
                    ? "bg-accent-indigo/10 text-accent-indigo"
                    : "text-text-secondary hover:bg-bg-tertiary"
                }`}
              >
                All
              </button>
              <button
                onClick={() => setActiveTab("Video")}
                className={`px-2 py-1 rounded text-xs transition-colors ${
                  activeTab === "Video"
                    ? "bg-accent-indigo/10 text-accent-indigo"
                    : "text-text-secondary hover:bg-bg-tertiary"
                }`}
              >
                Video
              </button>
              <button
                onClick={() => setActiveTab("Image")}
                className={`px-2 py-1 rounded text-xs transition-colors ${
                  activeTab === "Image"
                    ? "bg-accent-indigo/10 text-accent-indigo"
                    : "text-text-secondary hover:bg-bg-tertiary"
                }`}
              >
                Image
              </button>
              <button
                onClick={() => setActiveTab("Script")}
                className={`px-2 py-1 rounded text-xs transition-colors ${
                  activeTab === "Script"
                    ? "bg-accent-indigo/10 text-accent-indigo"
                    : "text-text-secondary hover:bg-bg-tertiary"
                }`}
              >
                Script
              </button>
            </div>
          </div>
          <div className="divide-y divide-white/5 max-h-80 overflow-y-auto">
            {historyLoading && (
              <div className="px-4 py-3 text-xs text-text-muted">
                Loading history...
              </div>
            )}
            {!historyLoading && historyError && (
              <div className="px-4 py-3 text-xs text-accent-red">
                {historyError}
              </div>
            )}
            {!historyLoading && !historyError && filteredHistory.length === 0 && (
              <div className="px-4 py-3 text-xs text-text-muted">
                No recent history yet.
              </div>
            )}
            {!historyLoading &&
              !historyError &&
              filteredHistory.map((item) => {
                const isProcessing =
                  item.status === "processing" || item.status === "pending";
                const displayTitle = truncateText(
                  item.title ?? item.prompt,
                  42
                );
                const displayTime = formatRelativeTime(item.created_at);
                const icon =
                  item.type === "video"
                    ? "🎬"
                    : item.type === "image"
                    ? "🖼️"
                    : item.type === "script"
                    ? "📝"
                    : "🎙️";
                const gradient =
                  item.type === "video"
                    ? "from-accent-pink/20 to-accent-purple/20"
                    : item.type === "image"
                    ? "from-accent-purple/20 to-accent-indigo/20"
                    : "from-accent-emerald/20 to-accent-blue/20";

                return (
                  <div
                    key={item.id}
                  className="px-4 py-3 flex items-center gap-3 hover:bg-white/2 cursor-pointer transition-colors"
                  onClick={() => setPreviewItem(item)}
                  >
                    <div
                      className={`w-12 h-12 rounded-lg flex items-center justify-center bg-linear-to-br ${gradient} ${
                        isProcessing ? "animate-pulse" : ""
                      }`}
                    >
                      {icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">{displayTitle}</p>
                      <p
                        className={`text-[10px] ${
                          isProcessing ? "text-accent-amber" : "text-text-muted"
                        }`}
                      >
                        {item.duration && `${item.duration} • `}
                        {item.aspect_ratio && `${item.aspect_ratio} • `}
                        {displayTime}
                      </p>
                    </div>
                    {isProcessing && (
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-accent-amber/10 text-accent-amber border border-accent-amber/20">
                        {item.progress ? `Pending (${item.progress}%)` : "Pending"}
                      </span>
                    )}
                    {item.favorited && (
                      <span className="text-accent-amber">⭐</span>
                    )}
                  </div>
                );
              })}
          </div>
        </div>

        </div>
      </div>



      {previewItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4 py-6"
          onClick={() => setPreviewItem(null)}
        >
          <div
            className="w-full max-w-3xl bg-bg-secondary border border-border-color rounded-2xl shadow-xl overflow-hidden"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-border-color flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold">
                  {truncateText(previewItem.title ?? previewItem.prompt, 80)}
                </h3>
                <p className="text-[11px] text-text-muted">
                  {previewItem.type.toUpperCase()} •{" "}
                  {formatRelativeTime(previewItem.created_at)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="text-text-muted hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="p-6 space-y-4">
              {previewItem.type === "video" && (
                <div className="space-y-3">
                  {previewItem.output_url ? (
                    <video
                      className="w-full rounded-xl border border-border-color bg-black"
                      controls
                      src={previewItem.output_url}
                    />
                  ) : (
                    <div className="w-full aspect-video rounded-xl border border-dashed border-border-color flex items-center justify-center text-xs text-text-muted">
                      Wait for video generation
                    </div>
                  )}
                  {previewItem.duration && previewItem.output_url && (
                    <p className="text-[11px] text-text-muted">
                      Duration: {previewItem.duration}
                    </p>
                  )}
                </div>
              )}
              {previewItem.type === "image" && (
                <div className="space-y-3">
                  {previewItem.output_url ? (
                    <img
                      src={previewItem.output_url}
                      alt={previewItem.title ?? previewItem.prompt}
                      className="w-full max-h-[480px] object-contain rounded-xl border border-border-color bg-black"
                    />
                  ) : (
                    <div className="w-full aspect-video rounded-xl border border-dashed border-border-color flex items-center justify-center text-xs text-text-muted">
                      No image URL set yet.
                    </div>
                  )}
                </div>
              )}
              {previewItem.type === "voice" && (
                <div className="space-y-3">
                  {previewItem.output_url ? (
                    <audio
                      className="w-full"
                      controls
                      src={previewItem.output_url}
                    />
                  ) : (
                    <div className="w-full rounded-xl border border-dashed border-border-color flex items-center justify-center text-xs text-text-muted px-4 py-10">
                      No audio URL set yet.
                    </div>
                  )}
                  <p className="text-xs text-text-muted">
                    {previewItem.style && `${previewItem.style} • `}
                    {previewItem.quality && `${previewItem.quality} • `}
                    {formatRelativeTime(previewItem.created_at)}
                  </p>
                </div>
              )}
              {previewItem.type === "script" && (
                <div className="space-y-3">
                  <div className="max-h-[340px] overflow-y-auto rounded-xl border border-border-color bg-bg-tertiary p-4 text-sm whitespace-pre-wrap">
                    {previewItem.prompt}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
