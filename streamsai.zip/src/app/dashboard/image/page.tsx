"use client";

import { useState } from "react";
import Link from "next/link";
import { useAuth } from "@/contexts/AuthContext";
import {
  createGeneration,
  type GenerationRecord,
} from "@/lib/generations";
import { formatRelativeTime, truncateText } from "@/lib/formatters";
import AIAssistant from "@/components/dashboard/AIAssistant";
import { useGenerationsQuery, usePrependGeneration } from "@/hooks/use-generations-query";

import QuickTemplates, { Template } from "@/components/dashboard/QuickTemplates";

const TEMPLATE_STORAGE_KEY = "streamsai.image.templates";

type ImageTemplate = Template & {
  prompt: string;
  aspectRatio: string;
  style: string;
};

const DEFAULT_TEMPLATES: ImageTemplate[] = [
  {
    id: "social-post",
    name: "Social Post",
    icon: "📱",
    uses: "3.2k",
    prompt: "A professional and eye-catching social media post with a clean layout and vibrant colors, engaging and minimal",
    aspectRatio: "1:1",
    style: "Realistic",
    isDefault: true,
  },
  {
    id: "website-hero",
    name: "Website Hero",
    icon: "💻",
    uses: "2.1k",
    prompt: "Stunning website hero image showing a futuristic cityscape or modern office environment, high resolution, wide angle",
    aspectRatio: "16:9",
    style: "Realistic",
    isDefault: true,
  },
  {
    id: "icon-logo",
    name: "App Icon",
    icon: "🎨",
    uses: "1.5k",
    prompt: "A modern, flat vector style app icon design, colorful gradients, simple shape, white background",
    aspectRatio: "1:1",
    style: "Cartoon",
    isDefault: true,
  },
  {
    id: "portrait-art",
    name: "Portrait Art",
    icon: "🖼️",
    uses: "980",
    prompt: "A detailed and expressive portrait of a character in a fantasy style, soft lighting, intricate details",
    aspectRatio: "9:16",
    style: "Artistic",
    isDefault: true,
  },
];

export default function ImagePage() {
  const { usage, usageLoading, incrementUsage } = useAuth();
  const [prompt, setPrompt] = useState("");
  const [aspectRatio, setAspectRatio] = useState("1:1");
  const [style, setStyle] = useState("Realistic");
  const [isGenerating, setIsGenerating] = useState(false);
  const [usageError, setUsageError] = useState("");
  const [previewItem, setPreviewItem] = useState<GenerationRecord | null>(null);
  const [activePreview, setActivePreview] = useState<GenerationRecord | null>(null);

  // React Query cache – instant data on back-navigation
  const { historyItems, historyLoading, historyError } = useGenerationsQuery({ type: "image", limit: 8 });
  const prependGeneration = usePrependGeneration();

  const isLimitReached =
    typeof usage?.limit === "number" && usage.used >= usage.limit;

  const handleGenerate = async () => {
    if (isLimitReached || usageLoading || isGenerating) {
      return;
    }

    if (!prompt.trim()) {
      setUsageError("Please enter a prompt.");
      return;
    }

    setUsageError("");
    setIsGenerating(true);

    const { error } = await incrementUsage(1);
    if (error) {
      setUsageError(error);
      setIsGenerating(false);
      return;
    }

    try {
      const created = await createGeneration({
        type: "image",
        prompt,
        title: truncateText(prompt, 48),
        status: "pending",
        aspectRatio,
        style,
      });
      // Optimistically inject into cache so the panel updates instantly
      prependGeneration(created);
      setActivePreview(created);
    } catch (createError) {
      setUsageError(
        createError instanceof Error
          ? createError.message
          : "Unable to save generation"
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleTemplateApply = (template: Template) => {
    const t = template as ImageTemplate;
    setPrompt(t.prompt);
    setAspectRatio(t.aspectRatio);
    setStyle(t.style);
  };

  const tabs = [
    { id: "script", label: "Script", icon: "📝" },
    { id: "voice", label: "Voice", icon: "🎙️" },
    { id: "image", label: "Image", icon: "🖼️" },
    { id: "video", label: "Video", icon: "🎬" },
  ];


  return (
    <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8">
      <div className="space-y-6">
        {/* Product Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {tabs.map((tab) => (
            <Link
              key={tab.id}
              href={`/dashboard/${tab.id}`}
              className={`flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium whitespace-nowrap transition-all ${
                tab.id === "image"
                  ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                  : "border-border-color bg-bg-secondary text-text-secondary hover:border-accent-indigo/50"
              }`}
            >
              <span className="text-xl">{tab.icon}</span> {tab.label}
            </Link>
          ))}
        </div>

        {/* Templates Bar */}
        <QuickTemplates
          storageKey={TEMPLATE_STORAGE_KEY}
          defaultTemplates={DEFAULT_TEMPLATES}
          onApply={handleTemplateApply}
        />

        {/* Main Generation Panel */}
        <div className="bg-bg-secondary border border-border-color rounded-2xl overflow-hidden">
          <div className="px-6 py-5 border-b border-border-color flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent-orange to-accent-red flex items-center justify-center">
                🖼️
              </div>
              <span className="font-semibold">Image Generation</span>
            </div>
          </div>

          <div className="p-6 space-y-6">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <span>✨</span> Describe your image
                </div>
                <span className="text-xs text-text-muted">
                  {prompt.length} / 500
                </span>
              </div>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full h-36 px-4 py-4 rounded-xl border border-border-color bg-bg-tertiary text-white text-[15px] leading-relaxed resize-none focus:outline-none focus:border-accent-indigo placeholder-text-muted"
                placeholder="A beautiful sunset over mountains with vibrant colors..."
                maxLength={500}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-bg-tertiary rounded-xl p-4">
                <p className="text-[10px] uppercase tracking-wider text-text-muted mb-3">
                  Aspect Ratio
                </p>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => setAspectRatio("16:9")}
                    className={`flex-1 py-2.5 rounded-lg border text-xs font-medium transition-colors ${
                      aspectRatio === "16:9"
                        ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                        : "border-border-color bg-bg-secondary text-text-secondary"
                    }`}
                  >
                    16:9
                  </button>
                  <button
                    onClick={() => setAspectRatio("9:16")}
                    className={`flex-1 py-2.5 rounded-lg border text-xs font-medium transition-colors ${
                      aspectRatio === "9:16"
                        ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                        : "border-border-color bg-bg-secondary text-text-secondary"
                    }`}
                  >
                    9:16
                  </button>
                  <button
                    onClick={() => setAspectRatio("1:1")}
                    className={`flex-1 py-2.5 rounded-lg border text-xs font-medium transition-colors ${
                      aspectRatio === "1:1"
                        ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                        : "border-border-color bg-bg-secondary text-text-secondary"
                    }`}
                  >
                    1:1
                  </button>
                </div>
              </div>
              <div className="bg-bg-tertiary rounded-xl p-4">
                <p className="text-[10px] uppercase tracking-wider text-text-muted mb-3">
                  Style
                </p>
                <select
                  value={style}
                  onChange={(e) => setStyle(e.target.value)}
                  className="w-full py-2.5 px-3 rounded-lg border border-border-color bg-bg-secondary text-white text-sm appearance-none cursor-pointer focus:outline-none focus:border-accent-indigo"
                >
                  <option>Realistic</option>
                  <option>Artistic</option>
                  <option>Cartoon</option>
                  <option>3D Render</option>
                </select>
              </div>
            </div>

            <button
              type="button"
              onClick={handleGenerate}
              disabled={isLimitReached || usageLoading || isGenerating}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-accent-orange to-accent-red text-white font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-accent-orange/30 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {isLimitReached
                ? "Limit Reached"
                : isGenerating
                ? "Generating..."
                : "✨ Generate Image"}
            </button>
            {usageError && (
              <p className="text-xs text-accent-red">{usageError}</p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Inline Preview / Shimmer */}
        {(isGenerating || activePreview) && (
          <div className="bg-bg-secondary border border-border-color rounded-2xl overflow-hidden p-6 shadow-xl relative mt-0">
            <h3 className="text-sm font-medium mb-4 flex items-center gap-2">
              <span className="text-accent-orange">👁️</span> Preview
            </h3>
            {isGenerating ? (
              <div className="w-full aspect-square md:aspect-video rounded-xl bg-bg-tertiary animate-pulse border border-border-color flex flex-col items-center justify-center gap-4 text-text-muted">
                <div className="w-12 h-12 rounded-full border-[3px] border-t-accent-orange border-r-transparent border-b-accent-red border-l-transparent animate-spin mb-2"></div>
                <p className="text-sm font-medium animate-pulse text-accent-orange">Generating your masterpiece...</p>
              </div>
            ) : activePreview ? (
              <div className="relative group rounded-xl overflow-hidden border border-border-color">
                {activePreview.output_url ? (
                  <img
                    src={activePreview.output_url}
                    alt={activePreview.title ?? activePreview.prompt}
                    className="w-full hover:scale-[1.02] transition-transform duration-500 object-cover bg-black"
                  />
                ) : (
                  <div className="w-full aspect-video flex flex-col items-center justify-center gap-2 bg-bg-tertiary text-xs text-accent-red">
                    <span>❌</span>
                    <span>Generation failed</span>
                  </div>
                )}
                
                {/* Overlay with details */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none flex flex-col justify-end p-4">
                  <p className="text-xs text-white drop-shadow-md">
                    {activePreview.aspect_ratio && `${activePreview.aspect_ratio} • `}
                    {activePreview.style}
                  </p>
                </div>
              </div>
            ) : null}
          </div>
        )}

        {/* AI Assistant */}
        <AIAssistant
          context={{
            type: "image",
            prompt,
            settings: { aspectRatio, style },
          }}
          onApplyPrompt={(newPrompt) => setPrompt(newPrompt)}
          onUpdateSettings={(key, value) => {
            if (key === "aspectRatio") setAspectRatio(value);
            if (key === "style") setStyle(value);
          }}
        />

        <div className="bg-bg-secondary border border-border-color rounded-2xl p-4">
          <h3 className="text-sm font-medium mb-3">Recent Images</h3>
          {historyLoading && (
            <p className="text-xs text-text-muted">Loading images...</p>
          )}
          {!historyLoading && historyError && (
            <p className="text-xs text-accent-red">{historyError}</p>
          )}
          {!historyLoading && !historyError && historyItems.length === 0 && (
            <p className="text-xs text-text-muted">No images generated yet</p>
          )}
          {!historyLoading &&
            !historyError &&
            historyItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-3 py-2 border-b border-white/[0.05] last:border-0 cursor-pointer hover:bg-white/5 rounded-lg px-2 -mx-2"
                onClick={() => setPreviewItem(item)}
              >
                <div
                  className={`w-10 h-10 rounded-lg bg-gradient-to-br from-accent-orange/20 to-accent-red/20 flex items-center justify-center ${
                    item.status === "pending" || item.status === "processing"
                      ? "animate-pulse"
                      : ""
                  }`}
                >
                  🖼️
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">
                    {truncateText(item.title ?? item.prompt, 40)}
                  </p>
                  <p className="text-[10px] text-text-muted">
                    {item.aspect_ratio && `${item.aspect_ratio} • `}
                    {item.style && `${item.style} • `}
                    {formatRelativeTime(item.created_at)}
                  </p>
                </div>
                {(item.status === "pending" || item.status === "processing") && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-accent-amber/10 text-accent-amber border border-accent-amber/20">
                    Pending
                  </span>
                )}
              </div>
            ))}
        </div>
      </div>
      {previewItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4 py-6"
          onClick={() => setPreviewItem(null)}
        >
          <div
            className="w-full max-w-3xl bg-bg-secondary border border-border-color rounded-2xl shadow-xl overflow-hidden"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-border-color flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold">
                  {truncateText(previewItem.title ?? previewItem.prompt, 80)}
                </h3>
                <p className="text-[11px] text-text-muted">
                  IMAGE • {formatRelativeTime(previewItem.created_at)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="text-text-muted hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="p-6 space-y-4">
              {previewItem.output_url ? (
                <img
                  src={previewItem.output_url}
                  alt={previewItem.title ?? previewItem.prompt}
                  className="w-full max-h-[480px] object-contain rounded-xl border border-border-color bg-black"
                />
              ) : (
                <div className="w-full aspect-video rounded-xl border border-dashed border-border-color flex items-center justify-center text-xs text-text-muted">
                  No image URL set yet.
                </div>
              )}
              <div className="text-xs text-text-muted">
                {previewItem.aspect_ratio && `${previewItem.aspect_ratio} • `}
                {previewItem.style && `${previewItem.style} • `}
                {formatRelativeTime(previewItem.created_at)}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
