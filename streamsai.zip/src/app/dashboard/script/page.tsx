"use client";

import { useState } from "react";
import Link from "next/link";
import { useAuth } from "@/contexts/AuthContext";
import {
  createGeneration,
  type GenerationRecord,
} from "@/lib/generations";
import { formatRelativeTime, truncateText } from "@/lib/formatters";
import AIAssistant from "@/components/dashboard/AIAssistant";
import { useGenerationsQuery, usePrependGeneration } from "@/hooks/use-generations-query";

import QuickTemplates, { Template } from "@/components/dashboard/QuickTemplates";

const TEMPLATE_STORAGE_KEY = "streamsai.script.templates";

type ScriptTemplate = Template & {
  prompt: string;
};

const DEFAULT_TEMPLATES: ScriptTemplate[] = [
  {
    id: "youtube-video",
    name: "YouTube Video",
    icon: "▶️",
    uses: "5.1k",
    prompt: "Write a script for a YouTube video about...",
    isDefault: true,
  },
  {
    id: "instagram-caption",
    name: "Instagram Caption",
    icon: "📸",
    uses: "4.2k",
    prompt: "Write an engaging Instagram caption for a photo of...",
    isDefault: true,
  },
  {
    id: "blog-post",
    name: "Blog Post",
    icon: "✍️",
    uses: "3.5k",
    prompt: "Write a comprehensive blog post about...",
    isDefault: true,
  },
  {
    id: "product-desc",
    name: "Product Desc",
    icon: "📦",
    uses: "2.1k",
    prompt: "Write a persuasive product description for...",
    isDefault: true,
  },
];

export default function ScriptPage() {
  const { usage, usageLoading, incrementUsage } = useAuth();
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [usageError, setUsageError] = useState("");
  const [previewItem, setPreviewItem] = useState<GenerationRecord | null>(null);
  const [activePreview, setActivePreview] = useState<GenerationRecord | null>(null);

  // React Query cache – instant data on back-navigation
  const { historyItems, historyLoading, historyError } = useGenerationsQuery({ type: "script", limit: 8 });
  const prependGeneration = usePrependGeneration();

  const isLimitReached =
    typeof usage?.limit === "number" && usage.used >= usage.limit;

  const handleGenerate = async () => {
    if (isLimitReached || usageLoading || isGenerating) {
      return;
    }

    if (!prompt.trim()) {
      setUsageError("Please enter a prompt.");
      return;
    }

    setUsageError("");
    setIsGenerating(true);

    const { error } = await incrementUsage(1);
    if (error) {
      setUsageError(error);
      setIsGenerating(false);
      return;
    }

    try {
      const created = await createGeneration({
        type: "script",
        prompt,
        title: truncateText(prompt, 48),
      });
      // Optimistically inject into cache so the panel updates instantly
      prependGeneration(created);
      setActivePreview(created);
    } catch (createError) {
      setUsageError(
        createError instanceof Error
          ? createError.message
          : "Unable to save generation"
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const handleTemplateApply = (template: Template) => {
    const t = template as ScriptTemplate;
    setPrompt(t.prompt);
  };

  const tabs = [
    { id: "script", label: "Script", icon: "📝" },
    { id: "voice", label: "Voice", icon: "🎙️" },
    { id: "image", label: "Image", icon: "🖼️" },
    { id: "video", label: "Video", icon: "🎬" },
  ];

  return (
    <div className="max-w-[1600px] mx-auto grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-8">
      <div className="space-y-6">
        {/* Product Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {tabs.map((tab) => (
            <Link
              key={tab.id}
              href={`/dashboard/${tab.id}`}
              className={`flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium whitespace-nowrap transition-all ${
                tab.id === "script"
                  ? "border-accent-indigo bg-accent-indigo/10 text-accent-indigo"
                  : "border-border-color bg-bg-secondary text-text-secondary hover:border-accent-indigo/50"
              }`}
            >
              <span className="text-xl">{tab.icon}</span> {tab.label}
            </Link>
          ))}
        </div>



        {/* Templates Bar */}
        <QuickTemplates
          storageKey={TEMPLATE_STORAGE_KEY}
          defaultTemplates={DEFAULT_TEMPLATES}
          onApply={handleTemplateApply}
        />

        {/* Main Generation Panel */}
        <div className="bg-bg-secondary border border-border-color rounded-2xl overflow-hidden">
          <div className="px-6 py-5 border-b border-border-color flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent-emerald to-accent-blue flex items-center justify-center">
                📝
              </div>
              <span className="font-semibold">Script Generation</span>
            </div>
          </div>

          <div className="p-6 space-y-6">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <span>✨</span> Describe your script
                </div>
                <span className="text-xs text-text-muted">
                  {prompt.length} / 2000
                </span>
              </div>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full h-48 px-4 py-4 rounded-xl border border-border-color bg-bg-tertiary text-white text-[15px] leading-relaxed resize-none focus:outline-none focus:border-accent-indigo placeholder-text-muted"
                placeholder="What kind of script do you need? (e.g., blog post, video script, social media content...)"
                maxLength={2000}
              />
            </div>

            <button
              type="button"
              onClick={handleGenerate}
              disabled={isLimitReached || usageLoading || isGenerating}
              className="w-full py-4 rounded-xl bg-gradient-to-r from-accent-emerald to-accent-blue text-white font-semibold flex items-center justify-center gap-2 hover:shadow-lg hover:shadow-accent-emerald/30 transition-all disabled:opacity-60 disabled:cursor-not-allowed"
            >
              {isLimitReached
                ? "Limit Reached"
                : isGenerating
                ? "Generating..."
                : "✨ Generate Script"}
            </button>
            {usageError && (
              <p className="text-xs text-accent-red">{usageError}</p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {/* Inline Preview / Shimmer */}
        {(isGenerating || activePreview) && (
          <div className="bg-bg-secondary border border-border-color rounded-2xl overflow-hidden p-6 shadow-xl relative mt-0">
            <h3 className="text-sm font-medium mb-4 flex items-center gap-2">
              <span className="text-accent-emerald">👁️</span> Preview
            </h3>
            {isGenerating ? (
              <div className="w-full h-32 rounded-xl bg-bg-tertiary animate-pulse border border-border-color flex flex-col items-center justify-center gap-2 text-text-muted p-4">
                <div className="text-2xl animate-bounce mb-2">📝</div>
                <div className="w-2/3 h-2 bg-text-muted/20 rounded mt-2"></div>
                <div className="w-1/2 h-2 bg-text-muted/20 rounded"></div>
                <div className="w-3/4 h-2 bg-text-muted/20 rounded"></div>
              </div>
            ) : activePreview ? (
              <div className="relative group rounded-xl overflow-hidden border border-border-color p-4 bg-bg-tertiary">
                <div className="max-h-60 custom-scrollbar overflow-y-auto text-sm text-text-secondary whitespace-pre-wrap">
                  {activePreview.prompt || "Generation failed or returned empty script."}
                </div>
              </div>
            ) : null}
          </div>
        )}

        {/* AI Assistant */}
        <AIAssistant
          context={{
            type: "script",
            prompt,
            settings: {},
          }}
          onApplyPrompt={(newPrompt) => setPrompt(newPrompt)}
        />

        <div className="bg-bg-secondary border border-border-color rounded-2xl p-4">
          <h3 className="text-sm font-medium mb-3">Recent Scripts</h3>
          {historyLoading && (
            <p className="text-xs text-text-muted">Loading scripts...</p>
          )}
          {!historyLoading && historyError && (
            <p className="text-xs text-accent-red">{historyError}</p>
          )}
          {!historyLoading && !historyError && historyItems.length === 0 && (
            <p className="text-xs text-text-muted">No scripts yet</p>
          )}
          {!historyLoading &&
            !historyError &&
            historyItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center gap-3 py-2 border-b border-white/[0.05] last:border-0 cursor-pointer hover:bg-white/5 rounded-lg px-2 -mx-2"
                onClick={() => setPreviewItem(item)}
              >
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-accent-emerald/20 to-accent-blue/20 flex items-center justify-center">
                  📝
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">
                    {truncateText(item.title ?? item.prompt, 40)}
                  </p>
                  <p className="text-[10px] text-text-muted">
                    {formatRelativeTime(item.created_at)}
                  </p>
                </div>
              </div>
            ))}
        </div>
      </div>
      {previewItem && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 px-4 py-6"
          onClick={() => setPreviewItem(null)}
        >
          <div
            className="w-full max-w-3xl bg-bg-secondary border border-border-color rounded-2xl shadow-xl overflow-hidden"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="px-6 py-4 border-b border-border-color flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold">
                  {truncateText(previewItem.title ?? previewItem.prompt, 80)}
                </h3>
                <p className="text-[11px] text-text-muted">
                  SCRIPT • {formatRelativeTime(previewItem.created_at)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPreviewItem(null)}
                className="text-text-muted hover:text-white"
              >
                ✕
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div className="max-h-[340px] overflow-y-auto rounded-xl border border-border-color bg-bg-tertiary p-4 text-sm whitespace-pre-wrap">
                {previewItem.prompt}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
