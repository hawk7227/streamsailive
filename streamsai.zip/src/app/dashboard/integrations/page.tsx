"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import IntegrationModal from "@/components/integrations/IntegrationModal";

const integrations = [
  {
    category: "Social Platforms",
    items: [
      {
        id: "facebook",
        name: "Facebook",
        description: "Post to Page",
        icon: (
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-[#1877F2]">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
          </svg>
        ),
        connected: false,
      },
      {
        id: "instagram",
        name: "Instagram",
        description: "Post to Feed",
        icon: (
          <svg viewBox="0 0 24 24" fill="url(#instagram-gradient)" className="w-8 h-8">
            <defs>
              <linearGradient id="instagram-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#833AB4" />
                <stop offset="50%" stopColor="#FD1D1D" />
                <stop offset="100%" stopColor="#F77737" />
              </linearGradient>
            </defs>
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.85-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.85-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
          </svg>
        ),
        connected: true,
      },
      {
        id: "tiktok",
        name: "TikTok",
        description: "Upload Video",
        icon: (
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-white">
            <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.65-1.55-1.07v8.32c0 2.91-1.78 5.6-4.5 6.71-2.72 1.11-6.16.54-8.07-1.37-1.91-1.92-2.48-5.36-.66-7.82 1.81-2.46 4.79-2.93 7.82-2.3v3.75c-.76-.46-1.7-.63-2.58-.45-1.69.34-2.77 2.1-2.23 3.73.54 1.64 2.5 2.51 4.09 1.83.67-.3 1.25-.8 1.64-1.43.39-.63.57-1.37.54-2.11V.02z" />
          </svg>
        ),
        connected: false,
      },
      {
        id: "youtube",
        name: "YouTube",
        description: "Upload Video",
        icon: (
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-[#FF0000]">
            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
          </svg>
        ),
        connected: false,
      },
      {
        id: "twitter",
        name: "Twitter/X",
        description: "Post Tweet",
        icon: (
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-[#1DA1F2]">
            <path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.84 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z" />
          </svg>
        ),
        connected: false,
      },
      {
        id: "linkedin",
        name: "LinkedIn",
        description: "Post Update",
        icon: (
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8 text-[#0077B5]">
            <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
          </svg>
        ),
        connected: false,
      },
    ],
  },
  {
    category: "Communication",
    items: [
      {
        id: "smtp",
        name: "SMTP",
        description: "Email Service",
        icon: (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-8 h-8 text-accent-emerald">
            <rect x="2" y="4" width="20" height="16" rx="2" />
            <path d="M22 6l-10 7L2 6" />
          </svg>
        ),
        connected: false,
      },
    ],
  },
  {
    category: "Utilities",
    items: [
      {
        id: "webhook",
        name: "Webhook Payload",
        description: "Receive Data",
        icon: (
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="w-8 h-8 text-accent-orange">
            <path d="M18 8a3 3 0 1 0-6 0 3 3 0 0 0 6 0z" />
            <path d="M18 16a3 3 0 1 0-6 0 3 3 0 0 0 6 0z" />
            <path d="M6 12a3 3 0 1 0-6 0 3 3 0 0 0 6 0z" />
            <path d="M6 12h6" />
            <path d="M15 10.5v3" />
          </svg>
        ),
        connected: true,
      },
    ],
  },
];

export default function IntegrationsPage() {
  const [activeTab, setActiveTab] = useState("all");
  const [connectedIntegrations, setConnectedIntegrations] = useState<Set<string>>(new Set());
  const [selectedIntegration, setSelectedIntegration] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [testEmailModalOpen, setTestEmailModalOpen] = useState(false);
  const [testEmailAddress, setTestEmailAddress] = useState("");
  const [sendingTestEmail, setSendingTestEmail] = useState(false);

  // Fetch integrations from database
  useEffect(() => {
    fetchIntegrations();
  }, []);

  const fetchIntegrations = async () => {
    try {
      const response = await fetch("/api/integrations?workflow_id=default-workflow");
      const data = await response.json();
      
      if (data.integrations) {
        const connected = new Set<string>(
          data.integrations
            .filter((i: any) => i.is_active)
            .map((i: any) => i.integration_type as string)
        );
        setConnectedIntegrations(connected);
      }
    } catch (error) {
      console.error("Failed to fetch integrations:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async (item: any) => {
    setSelectedIntegration(item);
    
    // If integration is already connected, fetch existing credentials
    if (connectedIntegrations.has(item.id)) {
      try {
        const response = await fetch(`/api/integrations/credentials?workflow_id=default-workflow&integration_type=${item.id}`);
        const data = await response.json();
        
        if (data.credentials) {
          setSelectedIntegration({ ...item, existingCredentials: data.credentials });
        }
      } catch (error) {
        console.error("Failed to fetch existing credentials:", error);
      }
    }
    
    setIsModalOpen(true);
  };

  const handleDisconnect = async (integrationType: string) => {
    if (!confirm("Are you sure you want to disconnect this integration?")) {
      return;
    }

    try {
      const response = await fetch(
        `/api/integrations?workflow_id=default-workflow&integration_type=${integrationType}`,
        { method: "DELETE" }
      );

      if (response.ok) {
        await fetchIntegrations();
      }
    } catch (error) {
      console.error("Failed to disconnect integration:", error);
    }
  };

  const handleSaveIntegration = async (formData: any) => {
    try {
      const response = await fetch("/api/integrations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          workflow_id: "default-workflow",
          integration_type: selectedIntegration.id,
          integration_name: selectedIntegration.name,
          credentials: formData,
          config: {},
        }),
      });

      if (response.ok) {
        await fetchIntegrations();
        setIsModalOpen(false);
      } else {
        const error = await response.json();
        alert(`Failed to save integration: ${error.error}`);
      }
    } catch (error) {
      console.error("Failed to save integration:", error);
      alert("Failed to save integration. Please try again.");
    }
  };

  const handleSendTestEmail = async () => {
    if (!testEmailAddress) {
      alert("Please enter a test email address");
      return;
    }

    setSendingTestEmail(true);
    try {
      const response = await fetch("/api/integrations/test-email", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          workflow_id: "default-workflow",
          test_email: testEmailAddress,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        alert(`✅ Test email sent successfully to ${testEmailAddress}!`);
        setTestEmailModalOpen(false);
        setTestEmailAddress("");
      } else {
        alert(`❌ Failed to send test email: ${data.error}`);
      }
    } catch (error) {
      console.error("Failed to send test email:", error);
      alert("❌ Failed to send test email. Please try again.");
    } finally {
      setSendingTestEmail(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent mb-2">
          Integrations
        </h1>
        <p className="text-text-secondary">
          Connect your favorite tools and platforms to automate your workflow
        </p>
      </div>

      <div className="space-y-8">
        {integrations.map((section) => (
          <div key={section.category}>
            <h2 className="text-lg font-semibold mb-4 text-text-primary">
              {section.category}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {section.items.map((item) => {
                const isConnected = connectedIntegrations.has(item.id);
                
                return (
                  <div
                    key={item.id}
                    className="group bg-bg-secondary border border-border-color hover:border-accent-indigo/50 rounded-2xl p-5 transition-all duration-300 hover:shadow-[0_4px_20px_rgba(99,102,241,0.1)] relative overflow-hidden"
                  >
                    {isConnected && (
                      <div className="absolute top-0 right-0 p-4">
                        <button
                          onClick={() => handleDisconnect(item.id)}
                          className="text-text-muted hover:text-red-500 transition-colors"
                          title="Disconnect"
                        >
                          <svg
                            viewBox="0 0 24 24"
                            fill="none"
                            stroke="currentColor"
                            strokeWidth="2"
                            className="w-5 h-5"
                          >
                            <circle cx="12" cy="12" r="10" />
                            <line x1="15" y1="9" x2="9" y2="15" />
                            <line x1="9" y1="9" x2="15" y2="15" />
                          </svg>
                        </button>
                      </div>
                    )}

                    <div className="flex flex-col h-full">
                      <div className="mb-4 p-3 bg-bg-tertiary rounded-xl w-fit group-hover:scale-110 transition-transform duration-300">
                        {item.icon}
                      </div>

                      <div className="mb-4">
                        <h3 className="font-semibold text-lg mb-1">{item.name}</h3>
                        <p className="text-sm text-text-muted">{item.description}</p>
                      </div>

                      <div className="mt-auto pt-4 border-t border-border-color/50">
                        {isConnected ? (
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2 text-accent-emerald text-sm font-medium">
                                <div className="w-2 h-2 rounded-full bg-accent-emerald animate-pulse" />
                                Connected
                              </div>
                              <button
                                onClick={() => handleConnect(item)}
                                className="text-xs text-text-muted hover:text-accent-indigo transition-colors"
                              >
                                Reconfigure
                              </button>
                            </div>
                            {item.id === "smtp" && (
                              <button
                                onClick={() => setTestEmailModalOpen(true)}
                                className="w-full py-2 rounded-lg border border-accent-emerald/30 bg-accent-emerald/5 text-sm font-medium text-accent-emerald hover:bg-accent-emerald/10 hover:border-accent-emerald/50 transition-all flex items-center justify-center gap-2"
                              >
                                <svg
                                  viewBox="0 0 24 24"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                  className="w-4 h-4"
                                >
                                  <path d="M22 2L11 13" />
                                  <path d="M22 2L15 22L11 13L2 9L22 2Z" />
                                </svg>
                                Send Test Email
                              </button>
                            )}
                          </div>
                        ) : (
                          <button
                            onClick={() => handleConnect(item)}
                            className="w-full py-2 rounded-lg border border-border-color text-sm font-medium text-text-secondary hover:text-white hover:border-accent-indigo hover:bg-accent-indigo/10 transition-all"
                          >
                            Connect
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {selectedIntegration && (
        <IntegrationModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          integration={selectedIntegration}
          onSave={handleSaveIntegration}
        />
      )}

      {/* Test Email Modal */}
      {testEmailModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-bg-secondary border border-border-color rounded-2xl max-w-md w-full">
            <div className="border-b border-border-color px-6 py-4">
              <h2 className="text-xl font-bold text-text-primary">Send Test Email</h2>
              <p className="text-sm text-text-secondary mt-1">
                Enter an email address to test your SMTP configuration
              </p>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2 text-text-primary">
                  Test Email Address
                </label>
                <input
                  type="email"
                  className="w-full px-4 py-2 rounded-lg bg-bg-tertiary border border-border-color focus:border-accent-indigo focus:outline-none text-text-primary"
                  placeholder="test@example.com"
                  value={testEmailAddress}
                  onChange={(e) => setTestEmailAddress(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === "Enter" && !sendingTestEmail) {
                      handleSendTestEmail();
                    }
                  }}
                />
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  onClick={() => {
                    setTestEmailModalOpen(false);
                    setTestEmailAddress("");
                  }}
                  className="flex-1 px-4 py-2 rounded-lg border border-border-color text-text-secondary hover:text-white hover:border-accent-indigo transition-all"
                  disabled={sendingTestEmail}
                >
                  Cancel
                </button>
                <button
                  onClick={handleSendTestEmail}
                  disabled={sendingTestEmail || !testEmailAddress}
                  className="flex-1 px-4 py-2 rounded-lg bg-accent-emerald hover:bg-accent-emerald/80 text-white font-medium transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {sendingTestEmail ? (
                    <>
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      Sending...
                    </>
                  ) : (
                    <>
                      <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        className="w-4 h-4"
                      >
                        <path d="M22 2L11 13" />
                        <path d="M22 2L15 22L11 13L2 9L22 2Z" />
                      </svg>
                      Send Test Email
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
